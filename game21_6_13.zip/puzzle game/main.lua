
-----------------------------------------------------------------------------------------

display.setStatusBar( display.HiddenStatusBar )

-- include the Corona "storyboard" module
local storyboard = require "storyboard"

local options =
{
    effect = "fade",
    time = 100,
    params = {
        var1 = "custom",
        myVar = "another"
    }
}

-- load menu screen
--storyboard.gotoScene( "game-scene")
--storyboard.gotoScene( "title_page")
--storyboard.gotoScene( "map")
--storyboard.gotoScene( "map_substate")
--storyboard.gotoScene( "ticket_shop")

--storyboard.gotoScene( "team_item")
--storyboard.gotoScene( "unit_main")
storyboard.gotoScene( "map")
--storyboard.gotoScene( "characterAll")
--storyboard.gotoScene( "guest")
--storyboard.gotoScene( "team_main")
--storyboard.gotoScene( "item_setting")
--storyboard.gotoScene( "team_select")
--storyboard.gotoScene( "map")
--storyboard.gotoScene( "commu_main")
--storyboard.gotoScene( "friend_list")
--storyboard.gotoScene( "character")



--storyboard.gotoScene( "request_list")
--storyboard.gotoScene( "shop_money")
--storyboard.gotoScene( "gacha")
--storyboard.gotoScene( "upgrade_main")
--storyboard.gotoScene( "power_up_main")
--storyboard.gotoScene( "battle_item")
--storyboard.gotoScene( "sell_item")
--storyboard.gotoScene( "team_select")
--storyboard.gotoScene( "shop_main")
--storyboard.gotoScene( "mission_clear")
--storyboard.gotoScene( "misstion")
--storyboard.gotoScene( "characterprofile")
--storyboard.gotoScene( "character_show")
--storyboard.gotoScene( "player_list")
--storyboard.gotoScene( "headTitle")
--storyboard.gotoScene( "menu_barLight")
--storyboard.gotoScene( "databaseConnect")
--storyboard.gotoScene( "team_item")
--storyboard.gotoScene( "includeFunction")
--storyboard.gotoScene( "discharge_main")
--storyboard.gotoScene( "characterAll")


