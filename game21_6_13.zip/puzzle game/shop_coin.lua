print("shop_coin")
local storyboard = require( "storyboard" )
local scene = storyboard.newScene()
local widget = require "widget"
local menu_barLight = require ("menu_barLight")
-----------------------------------------------------------------------------------------
local screenW, screenH = display.contentWidth, display.contentHeight
local backButton

local function onBtnRelease(event)
    if event.target.id == "back" then
        print( "event: "..event.target.id)
        storyboard.gotoScene( "shop_main" ,"fade", 100 )
    end
    return true
end

local function createButton()
    local image_btnback = "img/background/button/Button_BACK.png"
    backButton = widget.newButton{
        default= image_btnback,
        over= image_btnback,
        width= screenW/10, height= screenH/21,
        onRelease = onBtnRelease	-- event listener function
    }
    backButton.id="back"
    backButton:setReferencePoint( display.TopLeftReferencePoint )
    backButton.x = screenW- (screenW*.845)
    backButton.y = screenH - (screenH *.7)

end

function scene:createScene( event )
    print("--------------shop_coin----------------")
    local image_background = "img/background/shop/shopcoin.jpg"
    local image_text = "img/text/SHOP.png"
    local image_textcoin = "img/text/COIN.png"

    local group = self.view
    local gdisplay = display.newGroup()
    local background = display.newImageRect( image_background,screenW,screenH )
    background:setReferencePoint( display.TopLeftReferencePoint )
    background.x, background.y = 0, 0

    local titleText = display.newImageRect(image_text, screenW *.15, screenH/33 )
    titleText:setReferencePoint( display.CenterReferencePoint )
    titleText.x = screenW /2
    titleText.y = screenH /3.1

    local titleTextcoin = display.newImageRect(image_textcoin, screenW*.095, screenH*.021 )
    titleTextcoin:setReferencePoint( display.CenterReferencePoint )
    titleTextcoin.x = screenW*.75
    titleTextcoin.y = screenH* .32

    createButton()
    menu_barLight = menu_barLight.newMenubutton()
    gdisplay:insert(menu_barLight)

    group:insert(background)
    group:insert(titleText)
    group:insert(titleTextcoin)
    group:insert(backButton)
    group:insert(gdisplay)
    ------------- other scene ---------------
    storyboard.removeScene( "shop_main" )
    storyboard.removeScene( "shop_money" )
    storyboard.removeScene( "map" )

end

function scene:enterScene( event )
    local group = self.view
end

function scene:exitScene( event )
    local group = self.view
end

function scene:destroyScene( event )
    local group = self.view
end

scene:addEventListener( "createScene", scene )
scene:addEventListener( "enterScene", scene )
scene:addEventListener( "exitScene", scene )
scene:addEventListener( "destroyScene", scene )
return scene
