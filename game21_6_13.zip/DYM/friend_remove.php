<?php
//#USER guest.lua
include("include/connect.php");
$myuser_id = $_GET["user_id"];
$mycharacter_id = $_GET["character"];


?>
